<?php
if ($mysql_ok == "ok") mysqli_close($conx);
?>